﻿namespace CourseProjectGemoetry
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.figureSelector = new System.Windows.Forms.ComboBox();
            this.textBoxStrokeSize = new System.Windows.Forms.TextBox();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.fillColorButton = new System.Windows.Forms.Button();
            this.outlineColorButton = new System.Windows.Forms.Button();
            this.strokeSizeTip = new System.Windows.Forms.ToolTip(this.components);
            this.clearBoardButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // figureSelector
            // 
            this.figureSelector.FormattingEnabled = true;
            this.figureSelector.Location = new System.Drawing.Point(12, 12);
            this.figureSelector.Name = "figureSelector";
            this.figureSelector.Size = new System.Drawing.Size(129, 21);
            this.figureSelector.TabIndex = 0;
            this.figureSelector.SelectedIndexChanged += new System.EventHandler(this.figureSelector_SelectedIndexChanged);
            // 
            // textBoxStrokeSize
            // 
            this.textBoxStrokeSize.Location = new System.Drawing.Point(12, 39);
            this.textBoxStrokeSize.Name = "textBoxStrokeSize";
            this.textBoxStrokeSize.Size = new System.Drawing.Size(129, 20);
            this.textBoxStrokeSize.TabIndex = 1;
            this.strokeSizeTip.SetToolTip(this.textBoxStrokeSize, "Stroke size");
            // 
            // fillColorButton
            // 
            this.fillColorButton.Location = new System.Drawing.Point(12, 65);
            this.fillColorButton.Name = "fillColorButton";
            this.fillColorButton.Size = new System.Drawing.Size(129, 41);
            this.fillColorButton.TabIndex = 2;
            this.fillColorButton.Text = "Fill Color";
            this.fillColorButton.UseVisualStyleBackColor = true;
            this.fillColorButton.Click += new System.EventHandler(this.fillColorButton_Click);
            // 
            // outlineColorButton
            // 
            this.outlineColorButton.Location = new System.Drawing.Point(12, 112);
            this.outlineColorButton.Name = "outlineColorButton";
            this.outlineColorButton.Size = new System.Drawing.Size(129, 41);
            this.outlineColorButton.TabIndex = 3;
            this.outlineColorButton.Text = "Outline Color";
            this.outlineColorButton.UseVisualStyleBackColor = true;
            this.outlineColorButton.Click += new System.EventHandler(this.outlineColorButton_Click);
            // 
            // clearBoardButton
            // 
            this.clearBoardButton.Location = new System.Drawing.Point(12, 159);
            this.clearBoardButton.Name = "clearBoardButton";
            this.clearBoardButton.Size = new System.Drawing.Size(129, 42);
            this.clearBoardButton.TabIndex = 4;
            this.clearBoardButton.Text = "Clear Board";
            this.clearBoardButton.UseVisualStyleBackColor = true;
            this.clearBoardButton.Click += new System.EventHandler(this.clearBoardButton_Click);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(1262, 687);
            this.Controls.Add(this.clearBoardButton);
            this.Controls.Add(this.outlineColorButton);
            this.Controls.Add(this.fillColorButton);
            this.Controls.Add(this.textBoxStrokeSize);
            this.Controls.Add(this.figureSelector);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.MainForm_Paint);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox figureSelector;
        private System.Windows.Forms.TextBox textBoxStrokeSize;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.Button fillColorButton;
        private System.Windows.Forms.Button outlineColorButton;
        private System.Windows.Forms.ToolTip strokeSizeTip;
        private System.Windows.Forms.Button clearBoardButton;
    }
}

