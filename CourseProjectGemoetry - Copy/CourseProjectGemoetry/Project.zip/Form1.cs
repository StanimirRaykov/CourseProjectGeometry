﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace CourseProjectGemoetry
{
    public partial class Form1 : Form
    {
        private List<Figure> figures = new List<Figure>();
        private Point startPoint;
        private FigureType currentFigureType;
        private Figure currentFigure;
        private Point currentMousePosition;
        private int currentStrokeSize = 2;
        private Color outlineColor = Color.Black;
        private Color fillColor = Color.Transparent;
        public Form1()
        {
            InitializeComponent();
            figureSelector.DataSource = Enum.GetValues(typeof(FigureType));
            currentFigureType = FigureType.Rectangle;
            textBoxStrokeSize.TextChanged += TextBoxStrokeSize_TextChanged;
        }

        private void TextBoxStrokeSize_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxStrokeSize.Text, out int strokeSize))
            {
                if (strokeSize > 0)
                {
                    currentStrokeSize = strokeSize;
                }
                else
                {
                    textBoxStrokeSize.Text = currentStrokeSize.ToString();
                }
            }
            else
            {
                textBoxStrokeSize.Text = currentStrokeSize.ToString();
            }
        }
        private void MainForm_Paint(object sender, PaintEventArgs e)
        {
            foreach (Figure figure in figures)
            {
                figure.Fill(e.Graphics);
                figure.Draw(e.Graphics);

            }
            if (startPoint != Point.Empty && currentFigure != null)
            {
                currentFigure.SetDimensions(startPoint, currentMousePosition);
                currentFigure.Fill(e.Graphics);
                currentFigure.Draw(e.Graphics);
            }
        }

        private void MainForm_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                startPoint = e.Location;
                switch (currentFigureType)
                {
                    case FigureType.Rectangle:
                        currentFigure = new RectangleFigure(startPoint.X, startPoint.Y, 0, 0,currentStrokeSize, outlineColor,fillColor);
                        break;
                    case FigureType.Circle:
                        currentFigure = new EllipseFigure(startPoint.X, startPoint.Y, 0, 0,currentStrokeSize, outlineColor, fillColor);
                        break;
                }
            }
        }
        private void MainForm_MouseMove(object sender, MouseEventArgs e)
        {
            currentMousePosition = e.Location;
            Invalidate();
        }
        private void MainForm_MouseUp(object sender, MouseEventArgs e)
        {
            currentFigure.SetDimensions(startPoint, e.Location);
            figures.Add(currentFigure);
            Invalidate();
            startPoint = Point.Empty;
        }

        private void figureSelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            currentFigureType = (FigureType)figureSelector.SelectedItem;
        }

        private void fillColorButton_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                fillColor = colorDialog.Color;
                Invalidate();
            }
        }

        private void outlineColorButton_Click(object sender, EventArgs e)
        {
            ColorDialog colorDialog = new ColorDialog();
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                outlineColor = colorDialog.Color;
                Invalidate();
            }
        }

        private void clearBoardButton_Click(object sender, EventArgs e)
        {
            figures.Clear();
            Invalidate();
        }
    }
}

