﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseProjectGemoetry
{
    public enum FigureType
    {
        Rectangle,
        Circle,
        Triangle,
    }
}
